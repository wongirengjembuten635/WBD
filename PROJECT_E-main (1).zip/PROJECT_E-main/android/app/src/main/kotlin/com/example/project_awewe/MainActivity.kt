package com.example.project_awewe

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
